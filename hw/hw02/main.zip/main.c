#include <stdio.h>
#define  MAX  10000
#define MIN (-10000)

int main() {
    int input = 0;
    int max = 0, min = 0, pos = 0, odd = 0, total = 0, sum = 0, zero = 0;
    while(scanf("%d", &input) == 1) {
        if(input <= MAX && input >= MIN) {
            if (total != 0) { printf(", "); }
            total++;
            max = input >= max ? input : max;
            min = input <= min ? input : total == 1 ? input: min;
            if(input > 0) {
                pos++;
            }
            else if( input == 0) {
                zero++;
            }
            odd = input % 2 ? odd + 1 : odd;
            sum += input;
            printf("%d", input);
        } else {
            printf("\nError: Vstup je mimo interval!\n");
            return 100;
        }
    }
    printf("\n");
    printf("Pocet cisel: %d\n", total);
    printf("Pocet kladnych: %d\n", pos);
    printf("Pocet zapornych: %d\n", total - pos - zero);
    printf("Procento kladnych %.2f\n", (double)pos/total * 100);
    printf("Procento zapornych: %.2f\n", (double)(total - pos - zero)/total*100);
    printf("Pocet sudych: %d\n", total - odd);
    printf("Pocet lichych: %d\n", odd);
    printf("Procento sudych: %.2f\n", (double)(total-odd)/total * 100);
    printf("Procento lichych: %.2f\n", (double)odd/total*100);
    printf("Prumer: %.2f\n", (double)sum/total);
    printf("Maximum: %d\n", max);
    printf("Minimum: %d\n", min);
    return 0;

}
